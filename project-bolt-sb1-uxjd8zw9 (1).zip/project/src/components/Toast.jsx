import { useEffect } from 'react';
import { CheckCircle, XCircle, AlertCircle, Info, X } from 'lucide-react';
import { useToast } from '../context/ToastContext';

const Toast = ({ toast }) => {
  const { removeToast } = useToast();

  const getToastIcon = () => {
    switch (toast.type) {
      case 'success':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'error':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-amber-500" />;
      case 'info':
        return <Info className="w-5 h-5 text-blue-500" />;
      default:
        return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  const getToastStyles = () => {
    switch (toast.type) {
      case 'success':
        return 'bg-white border-green-200 text-green-800 shadow-green-100 dark:bg-gray-800 dark:border-green-800 dark:text-green-200 dark:shadow-green-900/20';
      case 'error':
        return 'bg-white border-red-200 text-red-800 shadow-red-100 dark:bg-gray-800 dark:border-red-800 dark:text-red-200 dark:shadow-red-900/20';
      case 'warning':
        return 'bg-white border-amber-200 text-amber-800 shadow-amber-100 dark:bg-gray-800 dark:border-amber-800 dark:text-amber-200 dark:shadow-amber-900/20';
      case 'info':
        return 'bg-white border-blue-200 text-blue-800 shadow-blue-100 dark:bg-gray-800 dark:border-blue-800 dark:text-blue-200 dark:shadow-blue-900/20';
      default:
        return 'bg-white border-blue-200 text-blue-800 shadow-blue-100 dark:bg-gray-800 dark:border-blue-800 dark:text-blue-200 dark:shadow-blue-900/20';
    }
  };

  return (
    <div
      className={`
        max-w-sm w-full shadow-lg rounded-xl pointer-events-auto border backdrop-blur-sm
        transform transition-all duration-300 ease-in-out animate-slide-up
        ${getToastStyles()}
      `}
    >
      <div className="p-4">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            {getToastIcon()}
          </div>
          <div className="ml-3 w-0 flex-1 pt-0.5">
            <p className="text-sm font-medium">{toast.message}</p>
          </div>
          <div className="ml-4 flex-shrink-0 flex">
            <button
              className="rounded-md inline-flex text-gray-400 hover:text-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors duration-200 dark:text-gray-500 dark:hover:text-gray-300"
              onClick={() => removeToast(toast.id)}
            >
              <span className="sr-only">Close</span>
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const ToastContainer = () => {
  const { toasts } = useToast();

  return (
    <div
      aria-live="assertive"
      className="fixed inset-0 flex items-end justify-center px-4 py-6 pointer-events-none sm:p-6 sm:items-start sm:justify-end z-50"
    >
      <div className="w-full flex flex-col items-center space-y-4 sm:items-end">
        {toasts.map((toast) => (
          <Toast key={toast.id} toast={toast} />
        ))}
      </div>
    </div>
  );
};

export default ToastContainer;