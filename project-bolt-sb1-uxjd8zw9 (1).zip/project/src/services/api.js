import axios from 'axios';

// Mock API base URL - replace with real API endpoint
const API_BASE_URL = 'https://api.example.com';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
});

// Add auth token to requests
api.interceptors.request.use((config) => {
  const user = localStorage.getItem('user');
  if (user) {
    const { token } = JSON.parse(user);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

// Mock data for development
export const mockEvents = [
  {
    id: '1',
    title: 'Tech Conference 2024',
    description: 'Annual technology conference featuring the latest trends in software development and AI.',
    date: '2024-03-15',
    time: '09:00',
    department: 'Computer Science',
    maxParticipants: 100,
    currentParticipants: 45,
    location: 'Main Auditorium',
    image: 'https://images.pexels.com/photos/1181676/pexels-photo-1181676.jpeg?auto=compress&cs=tinysrgb&w=500',
  },
  {
    id: '2',
    title: 'Research Symposium',
    description: 'Showcase of undergraduate and graduate research projects across various departments.',
    date: '2024-03-20',
    time: '14:00',
    department: 'Engineering',
    maxParticipants: 200,
    currentParticipants: 89,
    location: 'Engineering Building',
    image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=500',
  },
  {
    id: '3',
    title: 'Business Innovation Summit',
    description: 'Learn about entrepreneurship and business development from industry experts.',
    date: '2024-03-25',
    time: '10:00',
    department: 'Business',
    maxParticipants: 150,
    currentParticipants: 78,
    location: 'Business School Hall',
    image: 'https://images.pexels.com/photos/1181533/pexels-photo-1181533.jpeg?auto=compress&cs=tinysrgb&w=500',
  },
  {
    id: '4',
    title: 'Science Fair',
    description: 'Interactive science fair with demonstrations and experiments from various science departments.',
    date: '2024-04-02',
    time: '11:00',
    department: 'Science',
    maxParticipants: 300,
    currentParticipants: 156,
    location: 'Science Complex',
    image: 'https://images.pexels.com/photos/3184300/pexels-photo-3184300.jpeg?auto=compress&cs=tinysrgb&w=500',
  },
];

// Mock API functions
export const eventService = {
  getAllEvents: async () => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockEvents;
  },

  registerForEvent: async (eventId) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    // Mock registration logic
  },

  unregisterFromEvent: async (eventId) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    // Mock unregistration logic
  },

  createEvent: async (eventData) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const newEvent = {
      ...eventData,
      id: Math.random().toString(36).substr(2, 9),
      currentParticipants: 0,
    };
    mockEvents.push(newEvent);
    return newEvent;
  },

  updateEvent: async (eventId, eventData) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const eventIndex = mockEvents.findIndex(e => e.id === eventId);
    if (eventIndex !== -1) {
      mockEvents[eventIndex] = { ...mockEvents[eventIndex], ...eventData };
      return mockEvents[eventIndex];
    }
    throw new Error('Event not found');
  },

  deleteEvent: async (eventId) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const eventIndex = mockEvents.findIndex(e => e.id === eventId);
    if (eventIndex !== -1) {
      mockEvents.splice(eventIndex, 1);
    }
  },
};

export default api;